# Connect RX → PassKit Mapping Table

| Connect RX Object/Attribute   | User Mental Model Role             | PassKit Field/Component        | Visual/Animation Guidance                         | Privacy/Notes                                       |
|------------------------------|------------------------------------|-------------------------------|---------------------------------------------------|-----------------------------------------------------|
| PASSPORT.passport_id         | "My pass/card" (hidden)            | Not exposed in PassKit         | Never displayed                                   | Local-only                                          |
| PASSPORT.identity_token      | "Credential reference"             | Not exposed in PassKit         | Only used for backend/provider exchange           | Only passed between platform & provider             |
| PASSPORT.custodian           | "Who verified me"                  | Logo/Image, Secondary Field    | Soft logo or badge, no user-facing text           | No PII, org name or platform only                   |
| PASSPORT.expiration          | "Validity period"                  | Expiration Field, Back Field   | Shown as expiry date (soft color, no alerting)    | No time zone, date only if possible                 |
| PROVIDER.provider_name       | "Where I get support"              | Secondary/Aux Field            | Icon, badge, or short label if "direct to support"| Only for support cases                              |
| PROVIDER.support_type        | "Type of support"                  | Aux Field, Icon                | Subtle icon/label, never explicit medical detail  | Never user-facing details                           |
| PROVIDER.support_mode        | "Support method"                   | Not shown directly             | Impacts support CTA style (internal/external)     | Never PII                                           |
| CONNECT_RX_STATUS.status     | "Am I clear?"                      | Primary Field, Badge/Icon      | Animated badge: Liquid Glass for "clear"; gentle notification for "direct to support" | Only status, never test/result                      |
| CONNECT_RX_STATUS.expiration | "Status good until"                | Expiry/Back Field              | Subtle, never expiring warning or countdown       | Date only, not time or history                      |
| TRUSTMARK                   | "My trust signal"                   | Main Badge/Icon on Pass        | Iconic, animated, text-free for "clear"; support notification for "direct to support" | Never textual diagnosis                             |
| CONNECTION                   | "Handshake moment"                 | Not a pass, UI Animation/Effect| Animated badge(s) on both passes, visual confirmation, ripple or glow effect           | Ephemeral, never recorded, local event only         |
