# Connect RX Project — Wrap & Fork Protocol

## 1. Archive Your Work

**A. Download/Export All Key Artifacts:**
- Object model (`connect-rx-object-model.md`)
- PassKit mapping table (`swift_connect-rx-user-mental-model_mapping.md`)
- Brand & type addendum (`connect-rx_prompt_addendum.md`)
- Prompt packages, storyboards, and any .zip or .png files

**B. Save Your Prompt Log:**  
- Create or update a `prompt-log.md` (or Notion/Google Doc) containing:
    - Summary of session
    - Key decisions
    - Major artifacts (link/filename)
    - Any open questions or “where we left off”
- Optionally include all prompts you used/generated for reuse or audit.

**C. Archive Chat Transcript:**  
- Copy this chat (or use ChatGPT “export” feature)  
- Store with a timestamp in your project’s “chat archive” or versioned folder  
- Note last successful action and any “Next Steps”/instructions

---

## 2. Forking & Fresh Context Setup

### A. Use This Kickoff Prompt In Your New Chat:

> **Connect RX Project Fork — CONTEXT REFRESH**
>
> **Load the following artifacts before continuing:**
> - `connect-rx-object-model.md`
> - `swift_connect-rx-user-mental-model_mapping.md`
> - `connect-rx_prompt_addendum.md`
> - Latest storyboard images and prompt packages (upload or paste)
>
> **Pick up where we left off:**
> - [ ] Resume storyboard frame generation for the VERIFY protocol
> - [ ] Assemble final prompt/image demo kit for v0.dev or dev handoff
> - [ ] Any additional implementation tasks (list specifics as needed)
>
> **Project rules:**  
> - Strictly enforce brand palette, typefaces, and privacy principles as documented
> - All outputs must map to PassKit/iOS Wallet fields and object model as archived
> - Atomic prompts for each step; always generate both image and prompt card
> - Summarize progress after each major output
>
> **Open questions:**  
> - [Insert any open items or unresolved decisions here]
>
> **Ready to continue—context loaded.**

---

## 3. What To Upload/Load In New Thread

- All three canonical .md files
- Latest images/storyboard frames
- Any prior prompt package or in-progress .zip (if resuming export)
- A summary note or checklist as context for your next session

---

## 4. Optional — Emergency Protocol

If context is lost or session fails:
- Restore all artifacts from your prompt log or chat archive
- Use kickoff prompt above to reset new context window
- Continue work without redoing prior decisions/artifacts

---

# TL;DR – WRAP & FORK PROTOCOL

1. **Archive**: Download/export all files and chat logs
2. **Prompt Log**: Update with summary, filenames, and open tasks
3. **Fork**: Start new chat with kickoff prompt + checklist
4. **Upload**: All core files, images, and addenda in new thread
5. **Resume**: Storyboard/demo/implementation at exact point left off
