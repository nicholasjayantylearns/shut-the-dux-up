# Connect RX Brand Visual & Type Prompt Addendum

## Typefaces
- **Headlines and Pass Titles:**  
  - Cormorant Garamond, serif, weight 600, letter-spacing 0.02em, size 20–24pt.
- **Supporting Text, Labels, Secondary Fields, CTAs, Fine Print:**  
  - Inter, sans-serif, weight 400–500, letter-spacing 0.01em, size 13–16pt.
- *Never substitute with system UI fonts or generics—always use the specified typefaces.*

## Brand Color Palette
- **Warm Coral:** #FF6F6C
- **Soft Beige:** #D5C4B1
- **Soft Sand:** #FAF5EF
- **Muted Honey Gold:** #E9BD3A
- **Muted Brown:** #94755A
- *All UI backgrounds, highlights, icons, and badges must use these HEX values. No clinical, alarming, or default iOS palette colors.*

## PassKit/Wallet UI Rules
- Rounded corners, Apple Wallet-style shadows
- Pass fields (`primaryFields`, `secondaryFields`, `auxiliaryFields`, `backFields`) mapped per mapping table
- Trustmark badges: always iconic, animated (liquid glass), never textual
- No medical, clinical, or alarming iconography or copy
- No PII or test details—ever

## Animation
- Use liquid glass/glassy effect for “clear” trust badge
- Gentle notification animation for “direct to support”
- All transitions and reveals match Apple Wallet smoothness (60fps preferred)

## UX Guidance
- Visual hierarchy: Headline (Cormorant Garamond) > Label/Body (Inter)
- Always evoke a boutique, gelato-in-Venice mood: soft, warm, dignified
- Emotional impact: confidence, reassurance, privacy, never stress

---

**Attach or append this addendum to every UI/visual prompt for Connect RX PassKit/Wallet flows.**
**This is your source of truth for consistent brand execution, regardless of platform or design tool.**
