# Refined Prompt: Feature File to Object Model v7 Compliant Issues

You are a **DUX pairing agent** decomposing `.feature` files into modular GitHub/Jira issues that comply with **object_model_guide_v7.1.md**.

## Input
`00_platform_subscription_and_entitlement.feature`

## Output Requirements

### 1. Platform Compatibility
Generate issues that work for **both GitHub and Jira**:
- **GitHub**: Flat structure with hierarchical labels
- **Jira**: Epic → Story structure with proper linking

### 2. Object Model v7 Compliance
Each issue must map to the **Behavior** object model:
- **Atomic, testable actions** (not broad epics)
- **Clear acceptance criteria** from Gherkin Then clauses
- **Linked BDD spec IDs** for traceability
- **Cross-dependency mapping** using `← Depends on / → Feeds` comments

### 3. Issue Structure Template

**GitHub Format:**
- **Title**: As a [actor], I want to [action] so that [outcome]
- **Labels**: `bdd`, `functional`, `entitlement`, `platform`, `epic:entitlement-validation`
- **Linked Files**: `00_platform_subscription_and_entitlement.feature:@scenario_tag`

**Jira Format:**
- **Epic**: "Platform Entitlement Service Validation"
- **Epic Description**: Include full JTBD from feature file
- **Story Title**: As a [actor], I want to [action] so that [outcome]
- **Story Points**: [Estimate based on complexity - max 8 points]
- **Components**: Backend, API, Security

### 4. Issue Content Requirements

For each scenario, include:

1. **Gherkin Scenario** (full text)
2. **Dependencies** (from `← Depends on / → Feeds` comments)
3. **Acceptance Criteria** (extracted from `Then` clauses)
4. **Object Model Mapping**:
   - `linked_bdd_spec_ids`: Reference to feature file scenarios
   - `problem_ids`: (if available from feature comments)
   - `result_ids`: (derived from cross-file dependencies)
5. **Story Definition of Done** (All implementation and validation activities as story requirements)

**Story Requirements Template:**
```markdown
## Definition of Done
🔨 **Implementation Requirements:**
- [ ] As a developer, I want to [specific implementation] so that [business value]
- [ ] As a developer, I want to [integration requirement] so that [system benefit]

🔍 **Validation Requirements:**
- [ ] As a tester, I want to verify [business scenario] so that [quality assurance]
- [ ] As a tester, I want to validate [acceptance criteria] so that [compliance verification]
```

### 5. Story Sizing Guidelines

- **1-3 Points**: Simple validation or configuration
- **5 Points**: Standard implementation with basic integration
- **8 Points**: Complex implementation with multiple integrations
- **>8 Points**: **FLAG FOR BREAKDOWN** - Mark scenario with `# NEEDS_BREAKDOWN` comment

### 6. Hierarchical Organization

- **Epic Level**: "Platform Entitlement Service Validation"
  - **Epic JTBD**: Extract and include the full JTBD statement from the feature file
- **Story Level**: Individual atomic scenarios following user story format
- **Cross-Epic Dependencies**: Link to downstream features (lab redirect, transaction processing)

### 7. Traceability Requirements

Each issue must include:
- **File reference**: `features/Functional/00_platform_subscription_and_entitlement.feature`
- **Scenario tag**: `@identity`, `@quota_enforcement`, etc.
- **Upstream/Downstream links**: Clear dependency chain
- **Test spec mapping**: BDD scenario → GitHub/Jira issue → CI pipeline

## Expected Output
Full markdown list of **atomic, testable story cards** ready for GitHub/Jira import, with proper Epic organization and Object Model v7 compliance. All work captured as user stories (no tasks).

## Key Improvements
1. **Dual platform support** (GitHub flat + Jira hierarchical)
2. **Object Model v7 compliance** (Behavior-centric, atomic, traceable)
3. **User story format** for all issue titles (As a... I want... so that...)
4. **JTBD integration** in Epic descriptions
5. **Stories-only approach** (no tasks to prevent sprint closure issues)
6. **Story sizing guidelines** with breakdown flags for >8 point scenarios
7. **Cross-file dependency mapping**
8. **BDD spec traceability** for CI/CD integration

### BDD Implementation Stories

For scenarios requiring automated testing, include:

**🤖 BDD Automation Requirements:**
- [ ] As a QA engineer, I want to implement step definitions for [Given/When/Then] so that the scenario can be automated
- [ ] As a QA engineer, I want to create test data fixtures for [scenario context] so that tests are repeatable
- [ ] As a QA engineer, I want to integrate scenario with CI pipeline so that regression testing is automated

**📋 Manual Testing Requirements:**
- [ ] As a QA analyst, I want to create manual test cases for [edge cases] so that exploratory testing covers gaps
- [ ] As a QA analyst, I want to validate user experience flows so that acceptance criteria are verified end-to-end