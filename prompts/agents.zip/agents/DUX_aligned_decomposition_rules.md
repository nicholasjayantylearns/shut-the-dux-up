# DUX-Aligned Story Decomposition Rules

## Problem → Behavior → Result Mapping Rules

### **Rule 1: Single Problem Per Story**
Before creating a user story, identify the core Problem:
- What specific user/business issue does this scenario address?
- Can this Problem be solved in 1-5 points of work?
- If >5 points, decompose into multiple Problems

### **Rule 2: Behavior Atomicity Test**
Each Behavior (user story) must pass:
- ✅ **Single Action**: Can be completed in one development sprint
- ✅ **Single Actor**: Has one clear "As a..." statement  
- ✅ **Single Outcome**: Delivers one measurable Result
- ✅ **Testable**: Has clear acceptance criteria

### **Rule 3: Gherkin Scenario Decomposition**
When a Gherkin scenario contains multiple "And" clauses in the "Then" section:
- Each "And" clause likely represents a separate Problem
- Extract into individual user stories
- Maintain dependencies between the stories

## **Token Generation Example: DUX-Aligned Breakdown**

### **Original Scenario Analysis:**
```gherkin
@token_generation
Scenario: Generate secure redirect token for approved session
  Given platform "p01" is active and an approved session exists for testing
  When a test access request is made with session_nonce "abc123"
  Then a secure booking token is generated with 15-minute expiry
  And the token is mapped to session_nonce "abc123" (not user identity)
  And the session is redirected to lab booking flow with token
```

### **Problem Decomposition:**

**Problem 1**: "Approved sessions need time-limited security tokens"
- **User Scenario**: When I have an approved session
- **JTBD**: I want secure authentication that expires automatically
- **Target Outcome**: Session has valid, expiring access token

**Problem 2**: "User privacy must be preserved in token mapping"  
- **User Scenario**: When I receive an access token
- **JTBD**: I want my identity protected during the booking process
- **Target Outcome**: Token maps to session, not personal data

**Problem 3**: "Approved sessions need seamless journey continuation"
- **User Scenario**: When I'm approved for testing
- **JTBD**: I want immediate access to booking without re-authentication
- **Target Outcome**: Automatic redirect to booking with active token

### **Resulting User Stories:**

#### **Story 1: JWT Token Generation**
```markdown
**Title**: As a platform, I want to generate time-limited JWT tokens so that approved sessions have secure, expiring access
**Story Points**: 3
**Problem**: approved_sessions_need_secure_tokens
**Behavior**: generate_jwt_with_expiry
**Result**: secure_time_limited_access
```

#### **Story 2: Anonymous Token Mapping**  
```markdown
**Title**: As a user session, I want my token mapped to session_nonce so that my identity remains private during booking
**Story Points**: 2  
**Problem**: preserve_user_privacy_in_tokens
**Behavior**: map_token_to_session_nonce
**Result**: anonymous_booking_access
```

#### **Story 3: Secure Booking Redirect**
```markdown
**Title**: As an approved session, I want automatic redirect to booking flow so that I can continue seamlessly with my token
**Story Points**: 3
**Problem**: approved_sessions_need_seamless_continuation  
**Behavior**: redirect_with_secure_token
**Result**: seamless_booking_flow_entry
```

## **Agent Modification Rules**

### **New Decomposition Logic:**
1. **Parse "Then" clauses**: Count "And" statements
2. **If >1 "And"**: Flag for Problem decomposition
3. **Extract Problems**: Each "And" = potential separate Problem
4. **Create Behavior per Problem**: One user story per Problem
5. **Link Results**: Create dependency chain between stories
6. **Maintain traceability**: All stories link back to original scenario

### **Updated Story Point Thresholds:**
- **1-3 Points**: Single API/validation/config (✅ DUX atomic)
- **5 Points**: Single integration with basic complexity (✅ DUX atomic)  
- **8+ Points**: **ALWAYS DECOMPOSE** - violates DUX atomicity

### **Quality Gate:**
Before finalizing any story >5 points:
- Can this be broken into separate Problems?
- Does each Problem solve a distinct user/business need?
- Can each Problem be developed/tested independently?
